﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace APIIntegration.Models
{
    public class Services
    {
        public string Id { get; set; }
        public string Type { get; set; }
        public string Links { get; set; }
        public string Attributes { get; set; }
    }   
}
