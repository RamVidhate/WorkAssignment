﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Net.Http;
using APIIntegration.Models;

namespace APIIntegration.Controllers
{
    public class HomeController : Controller
    {
        public async Task<IActionResult> Index()
        {
            List < Services > servicesList = new List<Services>();

            using (var httpClient = new HttpClient())
            {
                using (var response = await httpClient.GetAsync("https://api.inquickerstaging.com/v3/winter.inquickerstaging.com/services"))
                {
                    string apiResponse = await response.Content.ReadAsStringAsync();
                    apiResponse = apiResponse.Replace("{\"data\":", "");
                    apiResponse = apiResponse.Replace(",\"meta\":{\"record-count\":11}}", "");
                    apiResponse = apiResponse.Replace("{\"self\":", "");
                    apiResponse = apiResponse.Replace("},\"attributes\"", ",\"attributes\"");
                    apiResponse = apiResponse.Replace("{\"name\":", "");
                    apiResponse = apiResponse.Replace("}},{\"id\":", "},{\"id\":");
                    apiResponse = apiResponse.Replace("\"}}]", "\"}]");
                   
                    servicesList = JsonConvert.DeserializeObject<List<Services>>(apiResponse);
               
                }
            }
            return View(servicesList);

        }
    }
}
